export interface Script {
  id: number
  title: string
  description: string
  category: string
  game: string
  author: string
  stars: number
  views: number
  date: string
  executors: string[]
  code: string
  tags: string[]
  comments: Comment[]
}

export interface Comment {
  id: number
  user: string
  avatar: string
  content: string
  date: string
  likes: number
}

