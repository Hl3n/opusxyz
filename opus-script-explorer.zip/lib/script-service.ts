import { StorageService } from "./storage-service"

export const ScriptService = {
  getAllScripts: () => {
    return StorageService.getAllScripts()
  },

  getScriptById: (id: number) => {
    return StorageService.getScriptById(id)
  },

  incrementViews: (id: number) => {
    return StorageService.incrementViews(id)
  },

  addScript: (script: any) => {
    return StorageService.addScript(script)
  },

  updateScript: (id: number, updates: any) => {
    return StorageService.updateScript(id, updates)
  },

  deleteScript: (id: number) => {
    return StorageService.deleteScript(id)
  },

  addComment: (scriptId: number, comment: any) => {
    return StorageService.addComment(scriptId, comment)
  },

  getUserRating: (scriptId: number) => {
    return StorageService.getUserRating(scriptId)
  },

  rateScript: (scriptId: number, rating: number) => {
    return StorageService.rateScript(scriptId, rating)
  },
}

