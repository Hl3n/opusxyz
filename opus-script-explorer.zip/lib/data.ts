import type { Script } from "./types"

export const scripts: Script[] = [
  {
    id: 1,
    title: "Infinite Yield",
    description: "Admin commands script with various utilities",
    category: "Utility",
    game: "Universal",
    author: "Edge",
    stars: 4.8,
    views: 15243,
    date: "2023-12-15",
    executors: ["Wave", "Xeno", "Solara", "Synapse Z", "Awp.gg", "Seliware"],
    tags: ["admin", "commands", "utility", "universal"],
    code: `-- Infinite Yield Admin Commands
local InfiniteYield = {}

function InfiniteYield:Initialize()
    print("Initializing Infinite Yield...")
    
    -- Setup variables
    self.Version = "5.9"
    self.Players = game:GetService("Players")
    self.LocalPlayer = self.Players.LocalPlayer
    
    -- Create UI
    self:CreateUI()
    
    -- Load commands
    self:LoadCommands()
    
    print("Infinite Yield initialized successfully!")
end

function InfiniteYield:CreateUI()
    -- UI code here
    local ScreenGui = Instance.new("ScreenGui")
    local MainFrame = Instance.new("Frame")
    
    ScreenGui.Parent = game:GetService("CoreGui")
    MainFrame.Parent = ScreenGui
    MainFrame.Size = UDim2.new(0, 400, 0, 300)
    MainFrame.Position = UDim2.new(0.5, -200, 0.5, -150)
    MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    
    -- More UI code would go here
end

function InfiniteYield:LoadCommands()
    self.Commands = {
        ["fly"] = function(args)
            -- Fly command implementation
            print("Executing fly command...")
        end,
        ["speed"] = function(args)
            -- Speed command implementation
            local speed = tonumber(args[1]) or 16
            self.LocalPlayer.Character.Humanoid.WalkSpeed = speed
        end,
        ["jump"] = function(args)
            -- Jump power command
            local power = tonumber(args[1]) or 50
            self.LocalPlayer.Character.Humanoid.JumpPower = power
        end
    }
end

-- Initialize the admin script
InfiniteYield:Initialize()

return InfiniteYield`,
    comments: [
      {
        id: 1,
        user: "ScriptMaster",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "This script works perfectly! Thanks for sharing.",
        date: "2024-02-15T14:30:00",
        likes: 12,
      },
      {
        id: 2,
        user: "LuaExpert",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "I've been using this for months, it's the best admin script out there.",
        date: "2024-02-10T09:15:00",
        likes: 8,
      },
      {
        id: 3,
        user: "GameDev2023",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "Works with the latest update, confirmed!",
        date: "2024-02-05T18:45:00",
        likes: 5,
      },
    ],
  },
  {
    id: 2,
    title: "Owl Hub",
    description: "Universal script with ESP and aimbot features",
    category: "Combat",
    game: "FPS Games",
    author: "CriShoux",
    stars: 4.5,
    views: 12876,
    date: "2023-11-20",
    executors: ["Wave", "Zenith", "Swift", "Macsploit", "Cryptic"],
    tags: ["aimbot", "esp", "combat", "fps"],
    code: `-- Owl Hub Universal Script
local OwlHub = {
    Version = "v2.5",
    Loaded = false,
    Settings = {
        ESP = true,
        Aimbot = true,
        AimbotKey = Enum.KeyCode.E,
        WallCheck = true
    }
}

function OwlHub:Init()
    print("Initializing Owl Hub " .. self.Version)
    
    -- Services
    self.Players = game:GetService("Players")
    self.RunService = game:GetService("RunService")
    self.UserInputService = game:GetService("UserInputService")
    
    -- Player references
    self.LocalPlayer = self.Players.LocalPlayer
    self.Camera = workspace.CurrentCamera
    
    -- Setup features
    self:SetupESP()
    self:SetupAimbot()
    
    self.Loaded = true
    print("Owl Hub loaded successfully!")
end

function OwlHub:SetupESP()
    -- ESP implementation
    self.RunService:BindToRenderStep("OwlESP", 1, function()
        if not self.Settings.ESP then return end
        
        for _, player in pairs(self.Players:GetPlayers()) do
            if player ~= self.LocalPlayer and player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
                -- Create or update ESP elements
                self:UpdateESP(player)
            end
        end
    end)
end

function OwlHub:SetupAimbot()
    -- Aimbot implementation
    self.UserInputService.InputBegan:Connect(function(input)
        if input.KeyCode == self.Settings.AimbotKey then
            self.AimbotActive = true
        end
    end)
    
    self.UserInputService.InputEnded:Connect(function(input)
        if input.KeyCode == self.Settings.AimbotKey then
            self.AimbotActive = false
        end
    end)
    
    self.RunService:BindToRenderStep("OwlAimbot", 2, function()
        if not self.Settings.Aimbot or not self.AimbotActive then return end
        
        local closestPlayer = self:GetClosestPlayer()
        if closestPlayer then
            -- Aim at player
            self:AimAt(closestPlayer)
        end
    end)
end

function OwlHub:GetClosestPlayer()
    -- Implementation to find closest player
    local closestPlayer = nil
    local shortestDistance = math.huge
    
    -- Logic to find closest player would go here
    
    return closestPlayer
end

-- Initialize Owl Hub
OwlHub:Init()

return OwlHub`,
    comments: [
      {
        id: 1,
        user: "AimbotKing",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "The aimbot in this script is insane! Highly recommend.",
        date: "2024-01-25T11:20:00",
        likes: 15,
      },
      {
        id: 2,
        user: "ESPMaster",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "ESP works through walls perfectly, no issues at all.",
        date: "2024-01-15T16:40:00",
        likes: 9,
      },
    ],
  },
  {
    id: 3,
    title: "Dark Hub",
    description: "Multi-game script with various features",
    category: "Multi-purpose",
    game: "Multiple Games",
    author: "Dark Hub Team",
    stars: 4.7,
    views: 18432,
    date: "2024-01-05",
    executors: ["Wave", "Xeno", "Solara", "Delta", "Codex"],
    tags: ["hub", "multi-game", "combat", "utility"],
    code: `-- Dark Hub Script
local DarkHub = {
    Version = "3.2",
    Games = {
        [286090429] = "Arsenal",
        [2377868063] = "Strucid",
        [2555870920] = "AceOfSpadez",
        [3233893879] = "Bad Business"
    }
}

function DarkHub:Init()
    print("Initializing Dark Hub " .. self.Version)
    
    -- Get current game
    local gameId = game.GameId
    local gameName = self.Games[gameId] or "Universal"
    
    print("Loading Dark Hub for: " .. gameName)
    
    -- Load appropriate module
    if gameName == "Arsenal" then
        self:LoadArsenal()
    elseif gameName == "Strucid" then
        self:LoadStrucid()
    elseif gameName == "AceOfSpadez" then
        self:LoadAceOfSpadez()
    elseif gameName == "Bad Business" then
        self:LoadBadBusiness()
    else
        self:LoadUniversal()
    end
    
    -- Create UI
    self:CreateUI()
    
    print("Dark Hub loaded successfully!")
end

function DarkHub:CreateUI()
    -- UI implementation
    local ScreenGui = Instance.new("ScreenGui")
    local MainFrame = Instance.new("Frame")
    
    ScreenGui.Parent = game:GetService("CoreGui")
    MainFrame.Parent = ScreenGui
    MainFrame.Size = UDim2.new(0, 500, 0, 350)
    MainFrame.Position = UDim2.new(0.5, -250, 0.5, -175)
    MainFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    MainFrame.BorderSizePixel = 0
    
    -- More UI code would go here
end

function DarkHub:LoadArsenal()
    -- Arsenal specific features
    print("Loading Arsenal module...")
end

function DarkHub:LoadStrucid()
    -- Strucid specific features
    print("Loading Strucid module...")
end

function DarkHub:LoadAceOfSpadez()
    -- AceOfSpadez specific features
    print("Loading AceOfSpadez module...")
end

function DarkHub:LoadBadBusiness()
    -- Bad Business specific features
    print("Loading Bad Business module...")
end

function DarkHub:LoadUniversal()
    -- Universal features
    print("Loading Universal module...")
end

-- Initialize Dark Hub
DarkHub:Init()

return DarkHub`,
    comments: [
      {
        id: 1,
        user: "GameHopper",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "Works on all the games I play! Great script hub.",
        date: "2024-01-20T10:15:00",
        likes: 18,
      },
    ],
  },
  {
    id: 4,
    title: "CMD-X",
    description: "Admin command script with over 600 commands",
    category: "Admin",
    game: "Universal",
    author: "CMD-X Team",
    stars: 4.6,
    views: 14321,
    date: "2023-10-18",
    executors: ["Wave", "Xeno", "Incognito", "Synapse Z"],
    tags: ["admin", "commands", "universal"],
    code: `-- CMD-X Admin Script
local CMDX = {
    Version = "1.5.7",
    Prefix = ";",
    Commands = {},
    Players = game:GetService("Players"),
    LocalPlayer = game:GetService("Players").LocalPlayer
}

function CMDX:Init()
    print("Initializing CMD-X " .. self.Version)
    
    -- Register commands
    self:RegisterCommands()
    
    -- Create UI
    self:CreateUI()
    
    -- Setup command handler
    self:SetupCommandHandler()
    
    print("CMD-X initialized with " .. #self.Commands .. " commands!")
end

function CMDX:RegisterCommands()
    -- Register all commands
    self:AddCommand("kill", "Kills the specified player", function(args)
        -- Kill command implementation
    end)
    
    self:AddCommand("fly", "Makes you fly", function(args)
        -- Fly command implementation
    end)
    
    self:AddCommand("noclip", "Lets you walk through walls", function(args)
        -- Noclip command implementation
    end)
    
    self:AddCommand("speed", "Changes your walkspeed", function(args)
        local speed = tonumber(args[1]) or 16
        self.LocalPlayer.Character.Humanoid.WalkSpeed = speed
    end)
    
    -- Many more commands would be registered here...
end

function CMDX:AddCommand(name, description, callback)
    table.insert(self.Commands, {
        Name = name,
        Description = description,
        Callback = callback
    })
end

function CMDX:CreateUI()
    -- UI implementation
    local ScreenGui = Instance.new("ScreenGui")
    local MainFrame = Instance.new("Frame")
    
    ScreenGui.Parent = game:GetService("CoreGui")
    MainFrame.Parent = ScreenGui
    MainFrame.Size = UDim2.new(0, 450, 0, 300)
    MainFrame.Position = UDim2.new(0.5, -225, 0.5, -150)
    MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    
    -- More UI code would go here
end

function CMDX:SetupCommandHandler()
    -- Command handler implementation
    self.LocalPlayer.Chatted:Connect(function(message)
        if message:sub(1, 1) == self.Prefix then
            local args = message:sub(2):split(" ")
            local commandName = args[1]:lower()
            table.remove(args, 1)
            
            for _, command in pairs(self.Commands) do
                if command.Name:lower() == commandName then
                    command.Callback(args)
                    break
                end
            end
        end
    end)
end

-- Initialize CMD-X
CMDX:Init()

return CMDX`,
    comments: [
      {
        id: 1,
        user: "CommandMaster",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "So many useful commands in one script! Love it.",
        date: "2023-12-05T14:20:00",
        likes: 11,
      },
    ],
  },
  {
    id: 5,
    title: "Domain X",
    description: "Universal script hub with game-specific features",
    category: "Hub",
    game: "Multiple Games",
    author: "Domain Team",
    stars: 4.4,
    views: 10987,
    date: "2024-02-01",
    executors: ["Xeno", "Solara", "Incognito", "Awp.gg"],
    tags: ["hub", "multi-game", "utility"],
    code: `-- Domain X Script Hub
local DomainX = {
    Version = "2.1.0",
    SupportedGames = {
        [286090429] = "Arsenal",
        [1962086868] = "Tower of Hell",
        [3527629287] = "Big Paintball",
        [2788229376] = "Da Hood"
    }
}

function DomainX:Init()
    print("Initializing Domain X " .. self.Version)
    
    -- Services
    self.Players = game:GetService("Players")
    self.LocalPlayer = self.Players.LocalPlayer
    self.RunService = game:GetService("RunService")
    self.UserInputService = game:GetService("UserInputService")
    
    -- Get current game
    local gameId = game.GameId
    self.CurrentGame = self.SupportedGames[gameId] or "Universal"
    
    print("Loading Domain X for: " .. self.CurrentGame)
    
    -- Create UI
    self:CreateUI()
    
    -- Load game-specific module
    self:LoadGameModule()
    
    print("Domain X loaded successfully!")
end

function DomainX:CreateUI()
    -- UI implementation
    local ScreenGui = Instance.new("ScreenGui")
    local MainFrame = Instance.new("Frame")
    
    ScreenGui.Parent = game:GetService("CoreGui")
    MainFrame.Parent = ScreenGui
    MainFrame.Size = UDim2.new(0, 550, 0, 350)
    MainFrame.Position = UDim2.new(0.5, -275, 0.5, -175)
    MainFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
    
    -- More UI code would go here
end

function DomainX:LoadGameModule()
    -- Load appropriate module based on game
    if self.CurrentGame == "Arsenal" then
        self:LoadArsenal()
    elseif self.CurrentGame == "Tower of Hell" then
        self:LoadTowerOfHell()
    elseif self.CurrentGame == "Big Paintball" then
        self:LoadBigPaintball()
    elseif self.CurrentGame == "Da Hood" then
        self:LoadDaHood()
    else
        self:LoadUniversal()
    end
end

function DomainX:LoadArsenal()
    -- Arsenal specific features
    print("Loading Arsenal module...")
    
    -- Arsenal features would be implemented here
end

function DomainX:LoadTowerOfHell()
    -- Tower of Hell specific features
    print("Loading Tower of Hell module...")
    
    -- Tower of Hell features would be implemented here
end

function DomainX:LoadBigPaintball()
    -- Big Paintball specific features
    print("Loading Big Paintball module...")
    
    -- Big Paintball features would be implemented here
end

function DomainX:LoadDaHood()
    -- Da Hood specific features
    print("Loading Da Hood module...")
    
    -- Da Hood features would be implemented here
end

function DomainX:LoadUniversal()
    -- Universal features
    print("Loading Universal module...")
    
    -- Universal features would be implemented here
end

-- Initialize Domain X
DomainX:Init()

return DomainX`,
    comments: [
      {
        id: 1,
        user: "DomainFan",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "Best script for Da Hood, works perfectly!",
        date: "2024-02-10T09:30:00",
        likes: 7,
      },
    ],
  },
  {
    id: 6,
    title: "Dex Explorer",
    description: "Game explorer tool for developers",
    category: "Developer",
    game: "Universal",
    author: "Moon",
    stars: 4.9,
    views: 20154,
    date: "2023-09-30",
    executors: ["Wave", "Xeno", "Solara", "Synapse Z", "Seliware"],
    tags: ["explorer", "developer", "utility", "universal"],
    code: `-- Dex Explorer
local Dex = {
    Version = "3.0"
}

function Dex:Init()
    print("Initializing Dex Explorer " .. self.Version)
    
    -- Services
    self.CoreGui = game:GetService("CoreGui")
    self.Players = game:GetService("Players")
    self.LocalPlayer = self.Players.LocalPlayer
    
    -- Create UI
    self:CreateUI()
    
    -- Setup explorer functionality
    self:SetupExplorer()
    
    print("Dex Explorer initialized successfully!")
end

function Dex:CreateUI()
    -- UI implementation
    local ScreenGui = Instance.new("ScreenGui")
    local MainFrame = Instance.new("Frame")
    
    ScreenGui.Name = "Dex"
    ScreenGui.Parent = self.CoreGui
    
    MainFrame.Name = "MainFrame"
    MainFrame.Parent = ScreenGui
    MainFrame.Size = UDim2.new(0, 600, 0, 400)
    MainFrame.Position = UDim2.new(0.5, -300, 0.5, -200)
    MainFrame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
    
    -- More UI code would go here
end

function Dex:SetupExplorer()
    -- Explorer implementation
    print("Setting up explorer functionality...")
    
    -- Create tree view
    self:CreateTreeView()
    
    -- Create property view
    self:CreatePropertyView()
    
    -- Setup selection handling
    self:SetupSelection()
end

function Dex:CreateTreeView()
    -- Tree view implementation
    print("Creating tree view...")
    
    -- Tree view code would go here
end

function Dex:CreatePropertyView()
    -- Property view implementation
    print("Creating property view...")
    
    -- Property view code would go here
end

function Dex:SetupSelection()
    -- Selection handling implementation
    print("Setting up selection handling...")
    
    -- Selection handling code would go here
end

-- Initialize Dex Explorer
Dex:Init()

return Dex`,
    comments: [
      {
        id: 1,
        user: "DevMaster",
        avatar: "/placeholder.svg?height=40&width=40",
        content: "Essential tool for any developer. Makes exploring game instances so much easier.",
        date: "2023-11-15T16:45:00",
        likes: 22,
      },
    ],
  },
]

