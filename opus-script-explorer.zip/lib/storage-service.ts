import type { Script, Comment } from "./types"
import { scripts as initialScripts } from "./data"

// Local storage keys
const SCRIPTS_STORAGE_KEY = "opus_scripts"
const USER_RATINGS_KEY = "opus_user_ratings"

// Initialize storage with default data if empty
const initializeStorage = () => {
  if (!localStorage.getItem(SCRIPTS_STORAGE_KEY)) {
    localStorage.setItem(SCRIPTS_STORAGE_KEY, JSON.stringify(initialScripts))
  }

  if (!localStorage.getItem(USER_RATINGS_KEY)) {
    localStorage.setItem(USER_RATINGS_KEY, JSON.stringify({}))
  }
}

// Get all scripts from storage
const getAllScripts = (): Script[] => {
  initializeStorage()
  const scriptsJson = localStorage.getItem(SCRIPTS_STORAGE_KEY)
  return scriptsJson ? JSON.parse(scriptsJson) : []
}

// Save all scripts to storage
const saveAllScripts = (scripts: Script[]) => {
  localStorage.setItem(SCRIPTS_STORAGE_KEY, JSON.stringify(scripts))
}

// Get user ratings
const getUserRatings = (): Record<number, number> => {
  const ratingsJson = localStorage.getItem(USER_RATINGS_KEY)
  return ratingsJson ? JSON.parse(ratingsJson) : {}
}

// Save user rating
const saveUserRating = (scriptId: number, rating: number) => {
  const ratings = getUserRatings()
  ratings[scriptId] = rating
  localStorage.setItem(USER_RATINGS_KEY, JSON.stringify(ratings))
}

export const StorageService = {
  // Script operations
  getAllScripts,
  saveAllScripts,

  getScriptById: (id: number): Script | undefined => {
    const scripts = getAllScripts()
    return scripts.find((script) => script.id === id)
  },

  addScript: (script: Omit<Script, "id" | "views" | "date" | "comments">): Script => {
    const scripts = getAllScripts()
    const newScript: Script = {
      ...script,
      id: scripts.length > 0 ? Math.max(...scripts.map((s) => s.id)) + 1 : 1,
      views: 0,
      date: new Date().toISOString(),
      comments: [],
    }

    scripts.push(newScript)
    saveAllScripts(scripts)
    return newScript
  },

  updateScript: (id: number, updates: Partial<Script>): Script | null => {
    const scripts = getAllScripts()
    const index = scripts.findIndex((script) => script.id === id)

    if (index !== -1) {
      scripts[index] = { ...scripts[index], ...updates }
      saveAllScripts(scripts)
      return scripts[index]
    }
    return null
  },

  deleteScript: (id: number): Script | null => {
    const scripts = getAllScripts()
    const index = scripts.findIndex((script) => script.id === id)

    if (index !== -1) {
      const deleted = scripts[index]
      const updatedScripts = scripts.filter((script) => script.id !== id)
      saveAllScripts(updatedScripts)
      return deleted
    }
    return null
  },

  incrementViews: (id: number): number => {
    const scripts = getAllScripts()
    const script = scripts.find((script) => script.id === id)

    if (script) {
      script.views += 1
      saveAllScripts(scripts)
      return script.views
    }
    return 0
  },

  // Comment operations
  addComment: (scriptId: number, comment: Omit<Comment, "id" | "date" | "likes">): Comment | null => {
    const scripts = getAllScripts()
    const script = scripts.find((script) => script.id === scriptId)

    if (script) {
      const newComment: Comment = {
        ...comment,
        id: script.comments.length > 0 ? Math.max(...script.comments.map((c) => c.id)) + 1 : 1,
        date: new Date().toISOString(),
        likes: 0,
      }

      script.comments.push(newComment)
      saveAllScripts(scripts)
      return newComment
    }
    return null
  },

  // Rating operations
  getUserRating: (scriptId: number): number | null => {
    const ratings = getUserRatings()
    return ratings[scriptId] || null
  },

  rateScript: (scriptId: number, rating: number): boolean => {
    const scripts = getAllScripts()
    const script = scripts.find((script) => script.id === scriptId)

    if (script) {
      // Save user rating
      saveUserRating(scriptId, rating)

      // Recalculate average rating (in a real app, this would be more sophisticated)
      // For simplicity, we'll just update the script's rating to the user's rating
      // In a real app, you'd calculate an average based on all user ratings
      script.stars = rating
      saveAllScripts(scripts)
      return true
    }
    return false
  },
}

