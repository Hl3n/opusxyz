"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Check } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { ScriptService } from "@/lib/script-service"
import { useRouter } from "next/navigation"

const EXECUTORS = [
  "Wave",
  "Xeno",
  "Solara",
  "Synapse Z",
  "Awp.gg",
  "Seliware",
  "Zenith",
  "Swift",
  "Macsploit",
  "Cryptic",
  "Delta",
  "Codex",
]

export default function SubmitForm() {
  const { toast } = useToast()
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [game, setGame] = useState("")
  const [category, setCategory] = useState("")
  const [author, setAuthor] = useState("")
  const [scriptCode, setScriptCode] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [currentTag, setCurrentTag] = useState("")
  const [selectedExecutors, setSelectedExecutors] = useState<string[]>([])

  const handleAddTag = () => {
    if (!currentTag.trim()) return
    if (tags.length >= 5) {
      toast({
        title: "Tag limit reached",
        description: "You can only add up to 5 tags",
        variant: "destructive",
      })
      return
    }

    if (!tags.includes(currentTag.trim())) {
      setTags([...tags, currentTag.trim()])
      setCurrentTag("")
    }
  }

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t) => t !== tag))
  }

  const toggleExecutor = (executor: string) => {
    if (selectedExecutors.includes(executor)) {
      setSelectedExecutors(selectedExecutors.filter((e) => e !== executor))
    } else {
      setSelectedExecutors([...selectedExecutors, executor])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !description || !game || !category || !author || !scriptCode || selectedExecutors.length === 0) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Option 1: Add directly to local storage (for demo purposes)
      ScriptService.addScript({
        title,
        description,
        game,
        category,
        author,
        stars: 0,
        code: scriptCode,
        tags,
        executors: selectedExecutors,
      })

      // Option 2: Send to webhook (for real implementation)
      const webhookUrl =
        "https://discord.com/api/webhooks/1346688376048324709/ryt7VW1TrBVYa489x1l1woQssgdz-Pbx16eB65vqqoVymiUtQ1ppGdPKyU2eUwfoHWG5"

      const payload = {
        content: "New Script Submission",
        embeds: [
          {
            title: title,
            description: description,
            color: 8388736, // Purple color
            fields: [
              {
                name: "Game",
                value: game,
                inline: true,
              },
              {
                name: "Category",
                value: category,
                inline: true,
              },
              {
                name: "Author",
                value: author,
                inline: true,
              },
              {
                name: "Tags",
                value: tags.length > 0 ? tags.join(", ") : "No tags",
                inline: true,
              },
              {
                name: "Supported Executors",
                value: selectedExecutors.join(", "),
                inline: true,
              },
              {
                name: "Script Code",
                value: scriptCode.length > 1000 ? scriptCode.substring(0, 997) + "..." : scriptCode,
              },
            ],
            footer: {
              text: "Opus Script Explorer",
            },
            timestamp: new Date().toISOString(),
          },
        ],
      }

      try {
        const response = await fetch(webhookUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        })
      } catch (error) {
        console.error("Webhook error:", error)
        // Continue even if webhook fails
      }

      setIsSuccess(true)
      toast({
        title: "Script submitted!",
        description: "Your script has been added successfully.",
      })

      // Reset form after 2 seconds
      setTimeout(() => {
        setTitle("")
        setDescription("")
        setGame("")
        setCategory("")
        setAuthor("")
        setScriptCode("")
        setTags([])
        setSelectedExecutors([])
        setIsSuccess(false)

        // Redirect to home page
        router.push("/")
      }, 2000)
    } catch (error) {
      toast({
        title: "Submission failed",
        description: "There was an error submitting your script. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl">Submit Your Script</CardTitle>
        <CardDescription>Share your Lua script with the Opus community</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="title">Script Title</Label>
              <Input
                id="title"
                placeholder="Enter a title for your script"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="game">Game</Label>
              <Input
                id="game"
                placeholder="Enter the game name (or Universal)"
                value={game}
                onChange={(e) => setGame(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                placeholder="Enter a category (e.g., Combat, Utility)"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="author">Author</Label>
              <Input
                id="author"
                placeholder="Enter your name or username"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe what your script does"
              className="min-h-[100px]"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="script">Script Code</Label>
            <Textarea
              id="script"
              placeholder="Paste your Lua script here"
              className="min-h-[200px] font-mono text-sm"
              value={scriptCode}
              onChange={(e) => setScriptCode(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Tags (up to 5)</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add a tag"
                value={currentTag}
                onChange={(e) => setCurrentTag(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    handleAddTag()
                  }
                }}
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleAddTag}
                disabled={tags.length >= 5 || !currentTag.trim()}
              >
                Add
              </Button>
            </div>

            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="px-2 py-1">
                    {tag}
                    <button
                      type="button"
                      className="ml-1 text-muted-foreground hover:text-foreground"
                      onClick={() => handleRemoveTag(tag)}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Supported Executors</Label>
            <div className="flex flex-wrap gap-2">
              {EXECUTORS.map((executor) => (
                <Badge
                  key={executor}
                  variant={selectedExecutors.includes(executor) ? "default" : "outline"}
                  className="cursor-pointer px-2 py-1"
                  onClick={() => toggleExecutor(executor)}
                >
                  {executor}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            disabled={isSubmitting || isSuccess}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : isSuccess ? (
              <>
                <Check className="mr-2 h-4 w-4" />
                Submitted!
              </>
            ) : (
              "Submit Script"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

