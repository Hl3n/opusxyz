"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { ThumbsUp, Clock } from "lucide-react"
import { motion } from "framer-motion"

interface Comment {
  id: number
  user: string
  avatar: string
  content: string
  date: string
  likes: number
}

interface CommentSectionProps {
  comments: Comment[]
  commentText: string
  setCommentText: (text: string) => void
  handleAddComment: () => void
  isCommentCooldown: boolean
}

export default function CommentSection({
  comments,
  commentText,
  setCommentText,
  handleAddComment,
  isCommentCooldown,
}: CommentSectionProps) {
  const [likedComments, setLikedComments] = useState<number[]>([])

  const handleLikeComment = (commentId: number) => {
    if (likedComments.includes(commentId)) {
      setLikedComments(likedComments.filter((id) => id !== commentId))
    } else {
      setLikedComments([...likedComments, commentId])
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - date.getTime())
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      const diffHours = Math.floor(diffTime / (1000 * 60 * 60))
      if (diffHours === 0) {
        const diffMinutes = Math.floor(diffTime / (1000 * 60))
        return `${diffMinutes} minute${diffMinutes !== 1 ? "s" : ""} ago`
      }
      return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
    } else if (diffDays < 7) {
      return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`
    } else {
      return date.toLocaleDateString()
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add a Comment</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Share your thoughts about this script..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="min-h-[100px]"
            disabled={isCommentCooldown}
          />
          {isCommentCooldown && (
            <div className="flex items-center text-sm text-muted-foreground mt-2">
              <Clock className="h-4 w-4 mr-1" />
              <span>Comment cooldown active. Please wait before posting again.</span>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button
            onClick={handleAddComment}
            disabled={!commentText.trim() || isCommentCooldown}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            Post Comment
          </Button>
        </CardFooter>
      </Card>

      <div className="space-y-4">
        {comments.map((comment, index) => (
          <motion.div
            key={comment.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.5 }}
          >
            <Card>
              <CardContent className="pt-6">
                <div className="flex gap-4">
                  <Avatar>
                    <AvatarImage src={comment.avatar} alt={comment.user} />
                    <AvatarFallback>{comment.user.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold">{comment.user}</div>
                      <div className="text-xs text-muted-foreground">{formatDate(comment.date)}</div>
                    </div>
                    <p className="mt-2 text-sm">{comment.content}</p>
                    <div className="mt-4 flex items-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`flex items-center gap-1 ${likedComments.includes(comment.id) ? "text-primary" : ""}`}
                        onClick={() => handleLikeComment(comment.id)}
                      >
                        <ThumbsUp className="h-4 w-4" />
                        <span>{comment.likes + (likedComments.includes(comment.id) ? 1 : 0)}</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

