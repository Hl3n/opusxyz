"use client"

import { useEffect, useRef, useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Copy, Check } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface LuaCodeBlockProps {
  code: string
}

export default function LuaCodeBlock({ code }: LuaCodeBlockProps) {
  const { toast } = useToast()
  const codeRef = useRef<HTMLPreElement>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!codeRef.current) return

    const highlightLua = (code: string) => {
      // Define regex patterns for Lua syntax
      const patterns = [
        { pattern: /(--[^\n]*)/g, className: "lua-comment" },
        {
          pattern: /\b(function|local|if|then|else|elseif|end|for|in|do|while|repeat|until|return|break|and|or|not)\b/g,
          className: "lua-keyword",
        },
        { pattern: /\b(true|false|nil)\b/g, className: "lua-keyword" },
        { pattern: /"([^"]*)"/g, className: "lua-string" },
        { pattern: /'([^']*)'/g, className: "lua-string" },
        { pattern: /\b(\d+(\.\d+)?)\b/g, className: "lua-number" },
        { pattern: /([A-Za-z_][A-Za-z0-9_]*):([A-Za-z_][A-Za-z0-9_]*)/g, className: "lua-function" },
        { pattern: /\b([A-Za-z_][A-Za-z0-9_]*)\(/g, className: "lua-function" },
        { pattern: /(\+|-|\*|\/|%|\^|#|==|~=|<|>|<=|>=|=|\.\.|\.)/g, className: "lua-operator" },
      ]

      let highlightedCode = code.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

      // Apply highlighting
      patterns.forEach(({ pattern, className }) => {
        highlightedCode = highlightedCode.replace(pattern, (match) => {
          return `<span class="${className}">${match}</span>`
        })
      })

      // Add line numbers
      const lines = highlightedCode.split("\n")
      let numberedCode = '<table class="w-full border-collapse"><tbody>'

      lines.forEach((line, index) => {
        numberedCode += `
          <tr>
            <td class="text-right pr-4 text-muted-foreground select-none border-r border-muted w-12">${index + 1}</td>
            <td class="pl-4">${line || " "}</td>
          </tr>
        `
      })

      numberedCode += "</tbody></table>"
      return numberedCode
    }

    codeRef.current.innerHTML = highlightLua(code)
  }, [code])

  const handleCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)

    toast({
      title: "Code copied!",
      description: "The script has been copied to your clipboard.",
      duration: 2000,
    })

    setTimeout(() => {
      setCopied(false)
    }, 2000)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="relative overflow-x-auto"
    >
      <div className="absolute top-2 right-2 z-10">
        <Button variant="secondary" size="sm" className="flex items-center gap-1" onClick={handleCopy}>
          {copied ? (
            <>
              <Check className="h-4 w-4" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy className="h-4 w-4" />
              <span>Copy</span>
            </>
          )}
        </Button>
      </div>
      <pre
        ref={codeRef}
        className="lua-code text-sm p-4 bg-[#282a36] text-[#f8f8f2] min-h-[300px] max-h-[600px] overflow-y-auto"
      ></pre>
    </motion.div>
  )
}

