"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Code } from "lucide-react"

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 10
      })
    }, 50)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="loading-container">
      <div className="flex flex-col items-center justify-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-4 rounded-xl">
            <Code size={40} className="text-white" />
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.3 }}
          className="text-3xl font-bold mb-1 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-blue-500"
        >
          Opus
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.3 }}
          className="text-lg text-muted-foreground mb-6"
        >
          #1 Script Explorer
        </motion.p>

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          className="h-1 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
          style={{ width: `${progress}%`, maxWidth: "250px" }}
        />
      </div>
    </div>
  )
}

