"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search, Code, Star, GamepadIcon, Eye, Clock, Plus, Filter, X } from "lucide-react"
import Link from "next/link"
import LoadingScreen from "@/components/loading-screen"
import Navbar from "@/components/navbar"
import { motion } from "framer-motion"
import type { Script } from "@/lib/types"
import { ScriptService } from "@/lib/script-service"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [scripts, setScripts] = useState<Script[]>([])
  const [filteredScripts, setFilteredScripts] = useState<Script[]>([])

  // Filter states
  const [games, setGames] = useState<string[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [selectedGames, setSelectedGames] = useState<string[]>([])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    // Load scripts
    const timer = setTimeout(() => {
      const allScripts = ScriptService.getAllScripts()
      setScripts(allScripts)

      // Extract unique games and categories for filters
      const uniqueGames = Array.from(new Set(allScripts.map((script) => script.game)))
      const uniqueCategories = Array.from(new Set(allScripts.map((script) => script.category)))

      setGames(uniqueGames)
      setCategories(uniqueCategories)

      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Apply filters and search
  useEffect(() => {
    let filtered = scripts

    // Apply game filter
    if (selectedGames.length > 0) {
      filtered = filtered.filter((script) => selectedGames.includes(script.game))
    }

    // Apply category filter
    if (selectedCategories.length > 0) {
      filtered = filtered.filter((script) => selectedCategories.includes(script.category))
    }

    // Apply search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (script) =>
          script.title.toLowerCase().includes(term) ||
          script.description.toLowerCase().includes(term) ||
          script.game.toLowerCase().includes(term) ||
          script.category.toLowerCase().includes(term) ||
          script.author.toLowerCase().includes(term) ||
          (script.tags && script.tags.some((tag) => tag.toLowerCase().includes(term))),
      )
    }

    setFilteredScripts(filtered)
  }, [searchTerm, scripts, selectedGames, selectedCategories])

  const toggleGameFilter = (game: string) => {
    setSelectedGames((prev) => (prev.includes(game) ? prev.filter((g) => g !== game) : [...prev, game]))
  }

  const toggleCategoryFilter = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const clearFilters = () => {
    setSelectedGames([])
    setSelectedCategories([])
    setSearchTerm("")
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center mb-12 text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-blue-500">
            Opus
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8">#1 Script Explorer</p>

          <div className="w-full max-w-md relative mb-4">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search scripts by name, game, category..."
              className="pl-10 pr-4 py-6"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-2"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter
                className={`h-4 w-4 ${selectedGames.length > 0 || selectedCategories.length > 0 ? "text-primary" : ""}`}
              />
            </Button>
          </div>

          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="w-full max-w-md mb-6 bg-card border rounded-lg p-4"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium">Filters</h3>
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  Clear All
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-2">Games</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {games.map((game) => (
                      <div key={game} className="flex items-center space-x-2">
                        <Checkbox
                          id={`game-${game}`}
                          checked={selectedGames.includes(game)}
                          onCheckedChange={() => toggleGameFilter(game)}
                        />
                        <Label htmlFor={`game-${game}`} className="text-sm cursor-pointer">
                          {game}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-2">Categories</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {categories.map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category}`}
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() => toggleCategoryFilter(category)}
                        />
                        <Label htmlFor={`category-${category}`} className="text-sm cursor-pointer">
                          {category}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {(selectedGames.length > 0 || selectedCategories.length > 0) && (
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedGames.map((game) => (
                <Badge key={`selected-${game}`} variant="secondary" className="px-2 py-1">
                  {game}
                  <button
                    type="button"
                    className="ml-1 text-muted-foreground hover:text-foreground"
                    onClick={() => toggleGameFilter(game)}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
              {selectedCategories.map((category) => (
                <Badge key={`selected-${category}`} variant="secondary" className="px-2 py-1">
                  {category}
                  <button
                    type="button"
                    className="ml-1 text-muted-foreground hover:text-foreground"
                    onClick={() => toggleCategoryFilter(category)}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </motion.div>

        <Tabs defaultValue="newest" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="newest">
              <Clock className="mr-2 h-4 w-4" />
              Newest
            </TabsTrigger>
            <TabsTrigger value="top">
              <Star className="mr-2 h-4 w-4" />
              Top Rated
            </TabsTrigger>
          </TabsList>

          <TabsContent value="newest" className="space-y-4">
            {filteredScripts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No scripts found matching your criteria.</p>
                <Button variant="link" onClick={clearFilters}>
                  Clear filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredScripts
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((script, index) => (
                    <ScriptCard key={script.id} script={script} index={index} />
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="top" className="space-y-4">
            {filteredScripts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No scripts found matching your criteria.</p>
                <Button variant="link" onClick={clearFilters}>
                  Clear filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredScripts
                  .sort((a, b) => b.stars - a.stars)
                  .map((script, index) => (
                    <ScriptCard key={script.id} script={script} index={index} />
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="mt-12 text-center"
        >
          <Link href="/submit">
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            >
              <Plus className="mr-2 h-4 w-4" />
              Submit Your Script
            </Button>
          </Link>
        </motion.div>
      </main>
    </div>
  )
}

function ScriptCard({ script, index }: { script: Script; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
    >
      <Link href={`/script/${script.id}`}>
        <Card className="h-full overflow-hidden hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <Badge variant="outline" className="mb-2">
                {script.category}
              </Badge>
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-500 mr-1" fill="currentColor" />
                <span>{script.stars.toFixed(1)}</span>
              </div>
            </div>
            <CardTitle className="text-xl">{script.title}</CardTitle>
            <CardDescription className="line-clamp-2">{script.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-muted-foreground mb-2">
              <Code className="h-4 w-4 mr-1" />
              <span>By {script.author}</span>
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <GamepadIcon className="h-4 w-4 mr-1" />
              <span>{script.game}</span>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between text-sm text-muted-foreground pt-0">
            <div className="flex items-center">
              <Eye className="h-4 w-4 mr-1" />
              <span>{script.views.toLocaleString()}</span>
            </div>
            <div>{new Date(script.date).toLocaleDateString()}</div>
          </CardFooter>
        </Card>
      </Link>
    </motion.div>
  )
}

