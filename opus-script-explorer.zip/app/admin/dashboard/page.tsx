"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"
import { Loader2, Plus, LogOut, X, Pencil, Trash, Eye, Search } from "lucide-react"
import { motion } from "framer-motion"
import type { Script } from "@/lib/types"
import { ScriptService } from "@/lib/script-service"

const EXECUTORS = [
  "Wave",
  "Xeno",
  "Solara",
  "Synapse Z",
  "Awp.gg",
  "Seliware",
  "Zenith",
  "Swift",
  "Macsploit",
  "Cryptic",
  "Delta",
  "Codex",
]

export default function AdminDashboard() {
  const { toast } = useToast()
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [game, setGame] = useState("")
  const [category, setCategory] = useState("")
  const [author, setAuthor] = useState("")
  const [scriptCode, setScriptCode] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [currentTag, setCurrentTag] = useState("")
  const [selectedExecutors, setSelectedExecutors] = useState<string[]>([])
  const [scripts, setScripts] = useState<Script[]>([])
  const [editingScript, setEditingScript] = useState<Script | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredScripts, setFilteredScripts] = useState<Script[]>([])

  useEffect(() => {
    // Check if user is authenticated
    const token = localStorage.getItem("adminToken")
    if (!token) {
      router.push("/admin/login")
    } else {
      setIsAuthenticated(true)
      // Load scripts
      const allScripts = ScriptService.getAllScripts()
      setScripts(allScripts)
      setFilteredScripts(allScripts)
    }
    setIsLoading(false)
  }, [router])

  // Filter scripts when search term changes
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredScripts(scripts)
      return
    }

    const term = searchTerm.toLowerCase()
    const filtered = scripts.filter(
      (script) =>
        script.title.toLowerCase().includes(term) ||
        script.description.toLowerCase().includes(term) ||
        script.game.toLowerCase().includes(term) ||
        script.category.toLowerCase().includes(term) ||
        script.author.toLowerCase().includes(term) ||
        (script.tags && script.tags.some((tag) => tag.toLowerCase().includes(term))),
    )

    setFilteredScripts(filtered)
  }, [searchTerm, scripts])

  const handleLogout = () => {
    localStorage.removeItem("adminToken")
    router.push("/admin/login")
  }

  const handleAddTag = () => {
    if (!currentTag.trim()) return
    if (tags.length >= 5) {
      toast({
        title: "Tag limit reached",
        description: "You can only add up to 5 tags",
        variant: "destructive",
      })
      return
    }

    if (!tags.includes(currentTag.trim())) {
      setTags([...tags, currentTag.trim()])
      setCurrentTag("")
    }
  }

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter((t) => t !== tag))
  }

  const toggleExecutor = (executor: string) => {
    if (selectedExecutors.includes(executor)) {
      setSelectedExecutors(selectedExecutors.filter((e) => e !== executor))
    } else {
      setSelectedExecutors([...selectedExecutors, executor])
    }
  }

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setGame("")
    setCategory("")
    setAuthor("")
    setScriptCode("")
    setTags([])
    setSelectedExecutors([])
    setEditingScript(null)
  }

  const handleEditScript = (script: Script) => {
    setEditingScript(script)
    setTitle(script.title)
    setDescription(script.description)
    setGame(script.game)
    setCategory(script.category)
    setAuthor(script.author)
    setScriptCode(script.code)
    setTags(script.tags || [])
    setSelectedExecutors(script.executors)
  }

  const handleDeleteScript = (scriptId: number) => {
    if (window.confirm("Are you sure you want to delete this script?")) {
      ScriptService.deleteScript(scriptId)

      // Refresh scripts list
      const updatedScripts = ScriptService.getAllScripts()
      setScripts(updatedScripts)
      setFilteredScripts(updatedScripts)

      toast({
        title: "Script deleted",
        description: "The script has been deleted successfully.",
      })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !description || !game || !category || !author || !scriptCode || selectedExecutors.length === 0) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      if (editingScript) {
        // Update existing script
        ScriptService.updateScript(editingScript.id, {
          title,
          description,
          game,
          category,
          author,
          code: scriptCode,
          tags,
          executors: selectedExecutors,
        })

        toast({
          title: "Script updated!",
          description: "The script has been updated successfully.",
        })
      } else {
        // Add new script
        ScriptService.addScript({
          title,
          description,
          game,
          category,
          author,
          stars: 0,
          code: scriptCode,
          tags,
          executors: selectedExecutors,
        })

        toast({
          title: "Script added!",
          description: "The script has been added successfully.",
        })
      }

      // Refresh scripts list
      const updatedScripts = ScriptService.getAllScripts()
      setScripts(updatedScripts)
      setFilteredScripts(updatedScripts)

      // Reset form
      resetForm()
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error processing your request.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-1.5 rounded-md">
              <Plus className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold">Admin Dashboard</span>
          </div>

          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <Tabs defaultValue={editingScript ? "add-script" : "manage-scripts"} className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
              <TabsTrigger value="add-script">{editingScript ? "Edit Script" : "Add Script"}</TabsTrigger>
              <TabsTrigger value="manage-scripts">Manage Scripts</TabsTrigger>
            </TabsList>

            <TabsContent value="add-script" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{editingScript ? "Edit Script" : "Add New Script"}</CardTitle>
                  <CardDescription>
                    {editingScript
                      ? "Edit an existing script in the Opus Script Explorer"
                      : "Add a new script to the Opus Script Explorer"}
                  </CardDescription>
                </CardHeader>
                <form onSubmit={handleSubmit}>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="title">Script Title</Label>
                        <Input
                          id="title"
                          placeholder="Enter a title for the script"
                          value={title}
                          onChange={(e) => setTitle(e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="game">Game</Label>
                        <Input
                          id="game"
                          placeholder="Enter the game name (or Universal)"
                          value={game}
                          onChange={(e) => setGame(e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="category">Category</Label>
                        <Input
                          id="category"
                          placeholder="Enter a category"
                          value={category}
                          onChange={(e) => setCategory(e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="author">Author</Label>
                        <Input
                          id="author"
                          placeholder="Enter the author's name"
                          value={author}
                          onChange={(e) => setAuthor(e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        placeholder="Describe what the script does"
                        className="min-h-[100px]"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="script">Script Code</Label>
                      <Textarea
                        id="script"
                        placeholder="Paste the Lua script here"
                        className="min-h-[200px] font-mono text-sm"
                        value={scriptCode}
                        onChange={(e) => setScriptCode(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Tags (up to 5)</Label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Add a tag"
                          value={currentTag}
                          onChange={(e) => setCurrentTag(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault()
                              handleAddTag()
                            }
                          }}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleAddTag}
                          disabled={tags.length >= 5 || !currentTag.trim()}
                        >
                          Add
                        </Button>
                      </div>

                      {tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="px-2 py-1">
                              {tag}
                              <button
                                type="button"
                                className="ml-1 text-muted-foreground hover:text-foreground"
                                onClick={() => handleRemoveTag(tag)}
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Supported Executors</Label>
                      <div className="flex flex-wrap gap-2">
                        {EXECUTORS.map((executor) => (
                          <Badge
                            key={executor}
                            variant={selectedExecutors.includes(executor) ? "default" : "outline"}
                            className="cursor-pointer px-2 py-1"
                            onClick={() => toggleExecutor(executor)}
                          >
                            {executor}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button type="button" variant="outline" onClick={resetForm}>
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {editingScript ? "Updating Script..." : "Adding Script..."}
                        </>
                      ) : (
                        <>{editingScript ? "Update Script" : "Add Script"}</>
                      )}
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>

            <TabsContent value="manage-scripts" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Manage Scripts</CardTitle>
                  <CardDescription>View, edit, and delete existing scripts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative mb-6">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search scripts..."
                      className="pl-10 pr-4"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  {filteredScripts.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      {scripts.length === 0
                        ? "No scripts to manage yet. Add some scripts first."
                        : "No scripts found matching your search."}
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {filteredScripts.map((script) => (
                        <Card key={script.id} className="overflow-hidden">
                          <CardHeader className="pb-2">
                            <div className="flex justify-between">
                              <div>
                                <CardTitle>{script.title}</CardTitle>
                                <CardDescription>{script.description}</CardDescription>
                              </div>
                              <div className="flex items-start gap-2">
                                <Button variant="ghost" size="icon" onClick={() => handleEditScript(script)}>
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDeleteScript(script.id)}
                                  className="text-destructive"
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pb-2">
                            <div className="flex flex-wrap gap-4 text-sm">
                              <div className="flex items-center">
                                <Badge variant="outline">{script.category}</Badge>
                              </div>
                              <div className="flex items-center">
                                <span className="text-muted-foreground mr-1">Game:</span>
                                <span>{script.game}</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-muted-foreground mr-1">Author:</span>
                                <span>{script.author}</span>
                              </div>
                              <div className="flex items-center">
                                <Eye className="h-4 w-4 mr-1 text-muted-foreground" />
                                <span>{script.views.toLocaleString()} views</span>
                              </div>
                            </div>
                            {script.tags && script.tags.length > 0 && (
                              <div className="flex flex-wrap gap-2 mt-4">
                                {script.tags.map((tag) => (
                                  <Badge key={tag} variant="secondary" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  )
}

