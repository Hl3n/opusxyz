"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Copy, Star, Eye, MessageSquare, Clock, AlertCircle, GamepadIcon } from "lucide-react"
import { motion } from "framer-motion"
import LoadingScreen from "@/components/loading-screen"
import Navbar from "@/components/navbar"
import LuaCodeBlock from "@/components/lua-code-block"
import CommentSection from "@/components/comment-section"
import type { Script } from "@/lib/types"
import { ScriptService } from "@/lib/script-service"

export default function ScriptPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [script, setScript] = useState<Script | null>(null)
  const [commentText, setCommentText] = useState("")
  const [isCommentCooldown, setIsCommentCooldown] = useState(false)
  const [userRating, setUserRating] = useState<number | null>(null)

  useEffect(() => {
    // Load script and increment views
    const timer = setTimeout(() => {
      const scriptId = Number.parseInt(params.id as string)
      const foundScript = ScriptService.getScriptById(scriptId)

      if (foundScript) {
        // Increment views
        ScriptService.incrementViews(scriptId)

        // Get user's previous rating if any
        const savedRating = ScriptService.getUserRating(scriptId)
        if (savedRating) {
          setUserRating(savedRating)
        }

        setScript(foundScript)
      }

      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [params.id])

  const handleCopyCode = () => {
    if (script) {
      navigator.clipboard.writeText(script.code)
      toast({
        title: "Code copied!",
        description: "The script has been copied to your clipboard.",
        duration: 3000,
      })
    }
  }

  const handleAddComment = () => {
    if (!commentText.trim() || !script) return

    // Add comment
    ScriptService.addComment(script.id, {
      user: "Guest User",
      avatar: "/placeholder.svg?height=40&width=40",
      content: commentText,
    })

    // Refresh script data
    setScript(ScriptService.getScriptById(script.id) || null)

    toast({
      title: "Comment added!",
      description: "Your comment has been posted successfully.",
      duration: 3000,
    })

    // Set cooldown
    setIsCommentCooldown(true)
    setCommentText("")

    setTimeout(() => {
      setIsCommentCooldown(false)
    }, 30000) // 30 seconds cooldown
  }

  const handleRate = (rating: number) => {
    if (!script) return

    setUserRating(rating)
    ScriptService.rateScript(script.id, rating)

    // Refresh script data to get updated rating
    setScript(ScriptService.getScriptById(script.id) || null)

    toast({
      title: "Rating submitted!",
      description: `You rated this script ${rating} stars!`,
      duration: 3000,
    })
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  if (!script) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16 text-center">
          <AlertCircle className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h1 className="text-3xl font-bold mb-4">Script Not Found</h1>
          <p className="text-muted-foreground mb-8">The script you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => router.push("/")}>Go Back</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className="text-xs">
                  {script.category}
                </Badge>
                <Badge variant="outline" className="text-xs bg-primary/10">
                  <GamepadIcon className="h-3 w-3 mr-1" />
                  {script.game}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  <Clock className="inline h-3 w-3 mr-1" />
                  {new Date(script.date).toLocaleDateString()}
                </span>
              </div>
              <h1 className="text-3xl font-bold">{script.title}</h1>
              <div className="flex items-center gap-2 mt-2">
                <div className="text-sm text-muted-foreground mr-2">Rate this script:</div>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => handleRate(star)}
                      className={`focus:outline-none ${
                        (userRating || script.stars) >= star ? "text-yellow-500" : "text-gray-400"
                      }`}
                    >
                      <Star className="h-5 w-5" fill={(userRating || script.stars) >= star ? "currentColor" : "none"} />
                    </button>
                  ))}
                </div>
                {userRating && <span className="text-sm text-muted-foreground">Your rating: {userRating}/5</span>}
              </div>
              <p className="text-muted-foreground mt-2">{script.description}</p>
              <div className="flex items-center gap-4 mt-4">
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-500 mr-1" fill="currentColor" />
                  <span>{script.stars.toFixed(1)}</span>
                </div>
                <div className="flex items-center">
                  <Eye className="h-4 w-4 mr-1" />
                  <span>{script.views.toLocaleString()} views</span>
                </div>
                <div className="flex items-center">
                  <MessageSquare className="h-4 w-4 mr-1" />
                  <span>{script.comments.length}</span>
                </div>
              </div>
              {script.tags && script.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {script.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <Button
                onClick={handleCopyCode}
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
              >
                <Copy className="mr-2 h-4 w-4" />
                Copy Script
              </Button>
            </div>
          </div>

          <Tabs defaultValue="script" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="script">Script</TabsTrigger>
              <TabsTrigger value="comments">Comments ({script.comments.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="script" className="space-y-4">
              <Card className="overflow-hidden">
                <CardHeader className="bg-muted/50 py-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Lua Script</CardTitle>
                    <Button variant="ghost" size="sm" onClick={handleCopyCode}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <LuaCodeBlock code={script.code} />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Compatible Executors</CardTitle>
                  <CardDescription>This script has been tested and works with the following executors</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {script.executors.map((executor: string) => (
                      <Badge key={executor} variant="secondary" className="text-sm py-1">
                        {executor}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="comments" className="space-y-4">
              <CommentSection
                comments={script.comments}
                commentText={commentText}
                setCommentText={setCommentText}
                handleAddComment={handleAddComment}
                isCommentCooldown={isCommentCooldown}
              />
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  )
}

