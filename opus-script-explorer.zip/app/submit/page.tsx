"use client"

import { useEffect, useState } from "react"
import Navbar from "@/components/navbar"
import SubmitForm from "@/components/submit-form"
import LoadingScreen from "@/components/loading-screen"
import { motion } from "framer-motion"

export default function SubmitPage() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Submit Your Script</h1>
            <p className="text-muted-foreground">Share your Lua script with the Opus community</p>
          </div>

          <SubmitForm />
        </motion.div>
      </main>
    </div>
  )
}

